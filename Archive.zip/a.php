<html>
<span onclick="f1();return false;">Couper</span>
<div id=dd>

<ul class="searchList" id="searchList1">


	<li id="LI_RECH-1"><a id="R_RECH-1" href="javascript:void(0);" onclick="insertKeyword('vis inox', 'R_RECH');">1 inox</a></li>
	<li id="LI_RECH-2"><a id="R_RECH-2" href="javascript:void(0);" onclick="insertKeyword('vis inoxydable', 'R_RECH');">2 inoxydable</a></li>
	<li id="LI_RECH-3"><a id="R_RECH-3" href="javascript:void(0);" onclick="insertKeyword('vis inoxydable.  garnitu', 'R_RECH');">3 inoxydable.  garnitu</a></li>
	<li id="LI_RECH-4"><a id="R_RECH-4" href="javascript:void(0);" onclick="insertKeyword('vis inomic', 'R_RECH');">4 inomic</a></li>
	<li id="LI_RECH-5"><a id="R_RECH-5" href="javascript:void(0);" onclick="insertKeyword('vis ino', 'R_RECH');">5 ino</a></li>

</ul>
</div>



<script>


function f1 () {

	 var liNodes= document.getElementsByTagName("li" );
	 var maxi = liNodes.length
	 var conti = true

	 while ( conti ) {

	   conti = false
	   for (var i = 0; i < maxi; i++ )   {

			try {
			var tmp = liNodes[i].getAttribute("id")

	   		if ( tmp != null  && tmp.substr(0, 8) == 'LI_RECH-' ) {
	   		 	liNodes[i].parentNode.removeChild(  liNodes[i] );
	   		 	conti = true
	   		 	break;
	   		}
	   	   } catch ( e ) {}
  		}
  	 }
	}


</script>


</html>