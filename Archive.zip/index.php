<?
    Header ("location: r.php");

?>