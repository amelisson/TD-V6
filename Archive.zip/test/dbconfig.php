<?php
// database connection settings
define("DB_HOSTNAME", "localhost" );
define("DB_USERNAME", "ame2" );
define("DB_PASSWORD", "ame2" );
define("DB_DATABASE", "trenois");
?>